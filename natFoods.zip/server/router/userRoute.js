const express = require("express")
const router = express.Router()

const { authMiddleware } = require("../middleware/auth-middleware")


const upload = require("../middleware/multer-middleware")
const { register } = require("module")
const { login, getInfo, editProfile, forgetPassword , addAddress , updateAddress ,deleteAddress ,setDefaultAddress, forgetPasswordOTP} = require("../controllers/user-Conntroller")


// Public routes
router.post("/register", register)
router.post("/login", login)
router.post("/forgot-password" , forgetPasswordOTP)

// Protected routes
router.get("/profile", authMiddleware, getInfo)
router.put("/profile", authMiddleware, editProfile)
router.post("/profile/picture", authMiddleware, upload.single("profilePic"))

// Address routes
router.post("/addresses", authMiddleware, addAddress)
router.put("/addresses/:addressId", authMiddleware, updateAddress)
router.delete("/addresses/:addressId", authMiddleware, deleteAddress)
router.put("/addresses/:addressId/default", authMiddleware, setDefaultAddress)



module.exports = router
