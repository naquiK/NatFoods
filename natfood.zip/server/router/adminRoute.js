const express = require("express")
const router = express.Router()
const Product = require("../model/product-model")
const User = require("../model/userModel")
const Order = require("../model/order-model")
const Settings = require("../model/settings-model")
const { authMiddleware } = require("../middleware/auth-middleware")
const { adminMiddleware } = require("../middleware/adminMiddleware")
const { checkPermission } = require("../middleware/permission-middleware")
const { cloudinary } = require("../config/cloudinary")

// Apply auth and admin middleware to all routes
router.use(authMiddleware, adminMiddleware)

// Dashboard stats
router.get("/stats", checkPermission("dashboard", "view"), async (req, res) => {
  try {
    const totalProducts = await Product.countDocuments({ isActive: true })
    const totalUsers = await User.countDocuments({ isAdmin: false }) // fix invalid query that caused cast errors; count non-admin users instead of role: "user"
    const totalOrders = await Order.countDocuments()
    const totalRevenue = await Order.aggregate([
      { $match: { status: "delivered" } },
      { $group: { _id: null, total: { $sum: "$totalAmount" } } },
    ])

    const recentOrders = await Order.find().populate("userId", "name email").sort({ createdAt: -1 }).limit(5)

    const lowStockProducts = await Product.find({
      $expr: { $lte: ["$stock", "$lowStockThreshold"] },
      isActive: true,
    }).limit(10)

    res.json({
      totalProducts,
      totalUsers,
      totalOrders,
      totalRevenue: totalRevenue[0]?.total || 0,
      recentOrders,
      lowStockProducts,
    })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
})

// Product management
router.get("/products", checkPermission("products", "view"), async (req, res) => {
  try {
    const { page = 1, limit = 20, category, search } = req.query
    const query = {}

    if (category) {
      query.category = category
    }

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
        { brand: { $regex: search, $options: "i" } },
      ]
    }

    const products = await Product.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)

    const total = await Product.countDocuments(query)

    res.json({
      products,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total,
    })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
})

router.post("/products", checkPermission("products", "create"), async (req, res) => {
  try {
    const body = { ...req.body }

    // normalize images array if present
    if (Array.isArray(body.images)) {
      body.images = body.images
        .filter(Boolean)
        .map((img) => ({
          url: img.url || img.path || img.secure_url,
          public_id: img.public_id || img.publicId || img.filename,
        }))
        .filter((i) => i.url && i.public_id)
    }

    const product = await Product.create(body)
    res.status(201).json({ message: "Product created successfully", product })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
})

router.put("/products/:id", checkPermission("products", "update"), async (req, res) => {
  try {
    const body = { ...req.body }

    if (Array.isArray(body.images)) {
      body.images = body.images
        .filter(Boolean)
        .map((img) => ({
          url: img.url || img.path || img.secure_url,
          public_id: img.public_id || img.publicId || img.filename,
        }))
        .filter((i) => i.url && i.public_id)
    }

    const product = await Product.findByIdAndUpdate(req.params.id, body, { new: true })
    if (!product) {
      return res.status(404).json({ message: "Product not found" })
    }
    res.json({ message: "Product updated successfully", product })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
})

router.delete("/products/:id", checkPermission("products", "delete"), async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
    if (!product) {
      return res.status(404).json({ message: "Product not found" })
    }

    const images = Array.isArray(product.images) ? product.images : []
    const publicIds = images.map((img) => img?.public_id || img?.publicId || img?.filename).filter(Boolean)

    if (publicIds.length) {
      try {
        await Promise.all(
          publicIds.map((pid) =>
            cloudinary.uploader.destroy(pid, {
              resource_type: "image",
            }),
          ),
        )
      } catch (err) {
        // log but do not block deletion if some images fail to delete
        console.log("Cloudinary delete error:", err?.message || err)
      }
    }

    await product.deleteOne()
    return res.json({ message: "Product and images deleted successfully" })
  } catch (error) {
    return res.status(500).json({ message: "Server error", error: error.message })
  }
})

// User management
router.get("/users", checkPermission("users", "view"), async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query
    const users = await User.find()
      .populate("role", "name description")
      .select("-password")
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)

    const total = await User.countDocuments()

    res.json({
      users,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total,
    })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
})

// Order management
router.get("/orders", checkPermission("orders", "view"), async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query
    const query = status ? { status } : {}

    const orders = await Order.find(query)
      .populate("userId", "name email")
      .populate("items.productId", "name price images")
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)

    const total = await Order.countDocuments(query)

    res.json({
      orders,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total,
    })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
})

router.put("/orders/:id/status", checkPermission("orders", "update"), async (req, res) => {
  try {
    const { status } = req.body
    const order = await Order.findByIdAndUpdate(req.params.id, { status }, { new: true })

    if (!order) {
      return res.status(404).json({ message: "Order not found" })
    }

    res.json({ message: "Order status updated successfully", order })
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message })
  }
})

module.exports = router
