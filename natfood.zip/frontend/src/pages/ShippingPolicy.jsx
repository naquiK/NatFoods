export default function ShippingPolicy() {
  return (
    <main className="min-h-screen pt-24" style={{ background: "var(--color-bg)", color: "var(--color-fg)" }}>
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="text-3xl font-serif mb-4">Shipping Policy</h1>
        <p style={{ color: "var(--color-muted)" }} className="mb-6">
          Learn about shipping methods, timelines, and costs.
        </p>
        <section className="space-y-4">
          <h2 className="text-xl font-semibold">Processing Time</h2>
          <p>Orders are processed within 1-2 business days.</p>
          <h2 className="text-xl font-semibold">Delivery Estimates</h2>
          <p>Expected delivery is typically 3-7 business days depending on location.</p>
        </section>
      </div>
    </main>
  )
}
