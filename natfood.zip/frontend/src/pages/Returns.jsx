export default function Returns() {
  return (
    <main className="min-h-screen pt-24" style={{ background: "var(--color-bg)", color: "var(--color-fg)" }}>
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="text-3xl font-serif mb-4">Cancellation & Returns</h1>
        <p style={{ color: "var(--color-muted)" }} className="mb-6">
          Understand our cancellation and returns process.
        </p>
        <section className="space-y-4">
          <h2 className="text-xl font-semibold">Order Cancellation</h2>
          <p>Orders can be cancelled before shipment. Contact support promptly.</p>
          <h2 className="text-xl font-semibold">Returns</h2>
          <p>Returns are accepted within 7 days of delivery if items are unused and in original packaging.</p>
        </section>
      </div>
    </main>
  )
}
